        // 错误日志系统
        const errorLog = document.getElementById('errorLog');
        
        function logError(message, error = null) {
            console.error(message, error);
            errorLog.style.display = 'block';
            errorLog.innerHTML += `<div>[${new Date().toLocaleTimeString()}] ${message}</div>`;
            if (error) {
                errorLog.innerHTML += `<div style="color: #ffaaaa;">${error.toString()}</div>`;
            }
        }
        
        function logInfo(message) {
            console.log(message);
            document.getElementById('gameStatus').textContent = message;
        }
        
        // 捕获全局错误
        window.addEventListener('error', (e) => {
            logError(`JavaScript错误: ${e.message}`, e.error);
        });
        
        // 游戏类
        class DragonHunterGame {
            constructor(canvas) {
                try {
                    logInfo('状态: 初始化游戏...');
                    
                    this.canvas = canvas;
                    this.ctx = canvas.getContext('2d');
                    
                    if (!this.ctx) {
                        throw new Error('无法获取Canvas 2D上下文');
                    }
                    
                    this.width = canvas.width;
                    this.height = canvas.height;
                    
                    // 游戏状态
                    this.gameStarted = false;
                    this.gameOver = false;
                    this.gamePaused = false;
                    this.score = 0;
                    this.level = 1;
                    
                    // 玩家
                    this.player = {
                        x: 100,
                        y: this.height / 2,
                        radius: 20,
                        speed: 200,
                        health: 100,
                        maxHealth: 100,
                        weaponLevel: 1,
                        shieldEnergy: 100,
                        speedBoost: 0,
                        powerBoost: 0,
                        size: 20,
                        skills: {
                            dash: { cooldown: 0, maxCooldown: 180 }, // 3秒冲刺
                            shield: { cooldown: 0, maxCooldown: 600, active: false, duration: 0 }, // 10秒护盾
                            powerShot: { cooldown: 0, maxCooldown: 300 } // 5秒强力射击
                        }
                    };
                    
                    // 石龙
                    this.stoneDragon = null;
                    this.bullets = [];
                    this.powerUps = [];
                    this.damageNumbers = [];
                    this.particles = []; // 粒子系统
                    this.flyingEnemies = []; // 飞行敌人系统
                    this.backgroundStars = this.generateStars(); // 生成背景星星
                    this.bossPhase = false; // boss战阶段
                    this.specialWeapons = []; // 特殊武器系统
                    this.treasureChests = []; // 宝箱系统
                    this.screenShake = 0; // 屏幕震动效果
                    
                    // 输入处理
                    this.keys = {};
                    this.setupEventListeners();
                    
                    // 创建石龙
                    this.createStoneDragon();
                    
                    logInfo('状态: 游戏初始化完成');
                    this.gameLoop();
                    
                } catch (error) {
                    logError('游戏初始化失败', error);
                }
            }
            
            setupEventListeners() {
                // 键盘事件
                document.addEventListener('keydown', (e) => {
                    this.keys[e.key.toLowerCase()] = true;
                });
                
                document.addEventListener('keyup', (e) => {
                    this.keys[e.key.toLowerCase()] = false;
                });
                
                // 鼠标点击开始游戏
                this.canvas.addEventListener('click', () => {
                    if (!this.gameStarted) {
                        this.startGame();
                    }
                });
            }
            
            createStoneDragon() {
                try {
                    logInfo('状态: 创建强化石龙...');
                    
                    // 根据等级调整龙的强度
                    const levelMultiplier = 1 + (this.level - 1) * 0.5;
                    const dragonTypes = ['fire', 'ice', 'lightning', 'shadow'];
                    const dragonType = dragonTypes[Math.floor(Math.random() * dragonTypes.length)];
                    
                    this.stoneDragon = {
                        segments: [],
                        direction: { x: -1, y: 0 },
                        speed: 60 + this.level * 10, // 增强移动速度
                        type: dragonType,
                        specialAttackCooldown: 0,
                        specialAttackTimer: 0,
                        rage: false,
                        rageTimer: 0
                    };
                    
                    // 创建强化龙头
                    this.stoneDragon.segments.push({
                        x: this.width - 100,
                        y: this.height / 2,
                        health: Math.floor(150 * levelMultiplier), // 大幅增加血量
                        maxHealth: Math.floor(150 * levelMultiplier),
                        isHead: true,
                        armor: 10 + this.level * 2, // 增加护甲
                        attackPower: 25 + this.level * 5 // 增加攻击力
                    });
                    
                    // 创建更多身体段
                    const segmentCount = 4 + Math.floor(this.level / 2);
                    for (let i = 1; i < segmentCount; i++) {
                        this.stoneDragon.segments.push({
                            x: this.width - 100 + i * 60,
                            y: this.height / 2,
                            health: Math.floor(100 * levelMultiplier), // 增强身体血量
                            maxHealth: Math.floor(100 * levelMultiplier),
                            isHead: false,
                            armor: 5 + this.level,
                            regeneration: this.level // 添加再生能力
                        });
                    }
                    
                    document.getElementById('dragonStats').textContent = 
                        `${dragonType.toUpperCase()}龙: ${this.stoneDragon.segments.length}段 (Lv.${this.level})`;
                    logInfo(`状态: ${dragonType}龙创建成功`);
                    
                } catch (error) {
                    logError('创建石龙失败', error);
                }
            }
            
            startGame() {
                this.gameStarted = true;
                logInfo('状态: 游戏开始！');
            }
            
            update() {
                if (!this.gameStarted || this.gameOver || this.gamePaused) return;
                
                try {
                    this.updatePlayer();
                    this.updateBullets();
                    this.updateStoneDragon();
                    this.updateDamageNumbers();
                    this.updateParticles();
                    this.updateHazards();
                    this.updateFlyingEnemies();
                    this.updateTreasureChests();
                    this.updateSpecialWeapons();
                    this.updateScreenShake();
                    this.spawnFlyingEnemies();
                    this.spawnTreasureChests();
                    this.autoShoot();
                    this.checkCollisions();
                    
                    // UI现在通过Canvas HUD渲染，不再需要DOM更新
                        
                } catch (error) {
                    logError('游戏更新失败', error);
                }
            }
            
            updatePlayer() {
                // 更新boost效果
                if (this.player.speedBoost > 0) {
                    this.player.speedBoost--;
                }
                if (this.player.powerBoost > 0) {
                    this.player.powerBoost--;
                }
                
                // 计算当前速度（含boost效果）
                let currentSpeed = this.player.speed;
                if (this.player.speedBoost > 0) {
                    currentSpeed *= 1.5; // 加速50%
                }
                const speed = currentSpeed / 60;
                
                // 更新技能冷却
                Object.values(this.player.skills).forEach(skill => {
                    if (skill.cooldown > 0) skill.cooldown--;
                    if (skill.duration > 0) skill.duration--;
                    if (skill.duration <= 0) skill.active = false;
                });
                
                // 更新特殊武器冷却
                if (this.specialWeaponCooldown > 0) {
                    this.specialWeaponCooldown--;
                }
                
                // 基础移动
                if (this.keys['w'] || this.keys['arrowup']) {
                    this.player.y = Math.max(this.player.radius, this.player.y - speed);
                }
                if (this.keys['s'] || this.keys['arrowdown']) {
                    this.player.y = Math.min(this.height - this.player.radius, this.player.y + speed);
                }
                if (this.keys['a'] || this.keys['arrowleft']) {
                    this.player.x = Math.max(this.player.radius, this.player.x - speed);
                }
                if (this.keys['d'] || this.keys['arrowright']) {
                    this.player.x = Math.min(this.width - this.player.radius, this.player.x + speed);
                }
                
                // 技能激活
                if (this.keys['shift'] && this.player.skills.dash.cooldown === 0) {
                    this.activateDash();
                }
                if (this.keys['space'] && this.player.skills.shield.cooldown === 0) {
                    this.activateShield();
                }
                if (this.keys['q'] && this.player.skills.powerShot.cooldown === 0) {
                    this.activatePowerShot();
                }
                
                // 特殊武器发射 (R键)
                if (this.keys['r'] && this.player.weaponLevel >= 3) {
                    this.launchSpecialWeapon();
                }
            }
            
            activateDash() {
                this.player.skills.dash.cooldown = this.player.skills.dash.maxCooldown;
                
                // 朝向最近的龙头冲刺
                if (this.stoneDragon && this.stoneDragon.segments.length > 0) {
                    const head = this.stoneDragon.segments[0];
                    const dx = head.x - this.player.x;
                    const dy = head.y - this.player.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance > 0) {
                        const dashDistance = 150;
                        this.player.x += (dx / distance) * dashDistance;
                        this.player.y += (dy / distance) * dashDistance;
                        
                        // 边界检查
                        this.player.x = Math.max(this.player.radius, 
                            Math.min(this.width - this.player.radius, this.player.x));
                        this.player.y = Math.max(this.player.radius, 
                            Math.min(this.height - this.player.radius, this.player.y));
                    }
                }
                
                logInfo('⚡ 冲刺技能激活！');
            }
            
            activateShield() {
                this.player.skills.shield.cooldown = this.player.skills.shield.maxCooldown;
                this.player.skills.shield.active = true;
                this.player.skills.shield.duration = 300; // 5秒护盾
                
                logInfo('🛡️ 护盾技能激活！');
            }
            
            activatePowerShot() {
                this.player.skills.powerShot.cooldown = this.player.skills.powerShot.maxCooldown;
                
                // 发射强力子弹
                if (this.stoneDragon && this.stoneDragon.segments.length > 0) {
                    const target = this.stoneDragon.segments[0];
                    const dx = target.x - this.player.x;
                    const dy = target.y - this.player.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance > 0) {
                        this.bullets.push({
                            x: this.player.x,
                            y: this.player.y,
                            vx: (dx / distance) * 15,
                            vy: (dy / distance) * 15,
                            damage: 50, // 高伤害
                            isPowerShot: true
                        });
                    }
                }
                
                logInfo('💥 强力射击激活！');
            }
            
            launchSpecialWeapon() {
                if (!this.specialWeaponCooldown) this.specialWeaponCooldown = 0;
                if (this.specialWeaponCooldown > 0) return;
                
                this.specialWeaponCooldown = 300; // 5秒冷却
                
                // 根据武器等级发射不同类型的特殊武器
                if (this.player.weaponLevel >= 5) {
                    // 发射多枚追踪导弹
                    for (let i = 0; i < 3; i++) {
                        this.specialWeapons.push({
                            type: 'missile',
                            x: this.player.x + 30,
                            y: this.player.y + (i - 1) * 20,
                            vx: 8,
                            vy: (i - 1) * 2,
                            damage: 100,
                            life: 300,
                            angle: 0
                        });
                    }
                    logInfo('🚀 发射追踪导弹群！');
                } else if (this.player.weaponLevel >= 3) {
                    // 发射单枚导弹
                    this.specialWeapons.push({
                        type: 'missile',
                        x: this.player.x + 30,
                        y: this.player.y,
                        vx: 8,
                        vy: 0,
                        damage: 150,
                        life: 300,
                        angle: 0
                    });
                    logInfo('🚀 发射追踪导弹！');
                }
                
                this.createScreenShake(10);
            }
            
            updateBullets() {
                this.bullets = this.bullets.filter(bullet => {
                    bullet.x += bullet.vx;
                    bullet.y += bullet.vy;
                    
                    return bullet.x > 0 && bullet.x < this.width && 
                           bullet.y > 0 && bullet.y < this.height;
                });
            }
            
            updateStoneDragon() {
                if (!this.stoneDragon) return;
                
                const time = Date.now() / 1000;
                const amplitude = 120 + this.level * 10; // 增加移动幅度
                const frequency = 0.6 + this.level * 0.1; // 增加移动频率
                
                // 更新特殊攻击冷却
                if (this.stoneDragon.specialAttackCooldown > 0) {
                    this.stoneDragon.specialAttackCooldown--;
                }
                
                // 检查是否进入狂暴状态
                const headSegment = this.stoneDragon.segments[0];
                if (headSegment && headSegment.health / headSegment.maxHealth < 0.3 && !this.stoneDragon.rage) {
                    this.stoneDragon.rage = true;
                    this.stoneDragon.rageTimer = 300; // 5秒狂暴
                    logInfo('⚡ 龙进入狂暴状态！');
                }
                
                if (this.stoneDragon.rage) {
                    this.stoneDragon.rageTimer--;
                    if (this.stoneDragon.rageTimer <= 0) {
                        this.stoneDragon.rage = false;
                    }
                }
                
                // 身体段再生
                this.stoneDragon.segments.forEach((segment, index) => {
                    if (!segment.isHead && segment.regeneration && segment.health < segment.maxHealth) {
                        segment.health = Math.min(segment.maxHealth, segment.health + segment.regeneration / 60);
                    }
                });
                
                // 移动逻辑
                this.stoneDragon.segments.forEach((segment, index) => {
                    if (index === 0) {
                        // 龙头智能移动 - 朝向玩家
                        const dx = this.player.x - segment.x;
                        const dy = this.player.y - segment.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance > 200) {
                            // 远距离时蛇形移动
                            segment.x -= this.stoneDragon.speed / 60;
                            segment.y = this.height / 2 + Math.sin(time * frequency + index) * amplitude;
                        } else {
                            // 近距离时追击玩家
                            const speed = this.stoneDragon.speed / 60 * (this.stoneDragon.rage ? 1.5 : 1);
                            segment.x += (dx / distance) * speed * 0.3;
                            segment.y += (dy / distance) * speed * 0.5;
                        }
                        
                        // 边界检查
                        if (segment.x < -50) {
                            segment.x = this.width + 50;
                        }
                        
                        // 特殊攻击
                        this.performSpecialAttack(segment);
                        
                    } else {
                        // 身体段跟随
                        const prev = this.stoneDragon.segments[index - 1];
                        const dx = prev.x - segment.x;
                        const dy = prev.y - segment.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance > 60) {
                            segment.x += (dx / distance) * (distance - 60);
                            segment.y += (dy / distance) * (distance - 60);
                        }
                    }
                });
            }
            
            performSpecialAttack(headSegment) {
                if (this.stoneDragon.specialAttackCooldown > 0) return;
                
                const distance = Math.sqrt(
                    Math.pow(this.player.x - headSegment.x, 2) + 
                    Math.pow(this.player.y - headSegment.y, 2)
                );
                
                if (distance < 150) {
                    this.stoneDragon.specialAttackCooldown = 180; // 3秒冷却
                    
                    switch (this.stoneDragon.type) {
                        case 'fire':
                            this.fireBreath(headSegment);
                            break;
                        case 'ice':
                            this.iceStorm(headSegment);
                            break;
                        case 'lightning':
                            this.lightningStrike(headSegment);
                            break;
                        case 'shadow':
                            this.shadowTeleport(headSegment);
                            break;
                    }
                }
            }
            
            fireBreath(headSegment) {
                logInfo('🔥 火龙喷射火焰！');
                // 创建火焰区域伤害
                const fireZones = [];
                for (let i = 0; i < 5; i++) {
                    const zoneX = headSegment.x - i * 50;
                    const zoneY = headSegment.y + (Math.random() - 0.5) * 100;
                    
                    fireZones.push({
                        x: zoneX,
                        y: zoneY,
                        radius: 40,
                        damage: 15,
                        duration: 120
                    });
                    
                    // 添加火焰粒子效果
                    this.createFireParticles(zoneX, zoneY);
                }
                this.hazards = (this.hazards || []).concat(fireZones);
                
                // 创建火焰爆炸效果
                this.createExplosion(headSegment.x, headSegment.y, 'fire');
            }
            
            iceStorm(headSegment) {
                logInfo('❄️ 冰龙召唤暴风雪！');
                // 减缓玩家速度
                this.player.speed = Math.max(50, this.player.speed * 0.5);
                setTimeout(() => {
                    this.player.speed = 200;
                }, 3000);
                
                // 创建冰霜粒子效果
                for (let i = 0; i < 20; i++) {
                    const angle = Math.random() * Math.PI * 2;
                    const distance = Math.random() * 150;
                    const x = headSegment.x + Math.cos(angle) * distance;
                    const y = headSegment.y + Math.sin(angle) * distance;
                    this.createIceParticles(x, y);
                }
                
                this.createExplosion(headSegment.x, headSegment.y, 'ice');
            }
            
            lightningStrike(headSegment) {
                logInfo('⚡ 雷龙释放闪电！');
                // 直接伤害玩家
                const damage = 20;
                this.player.health = Math.max(0, this.player.health - damage);
                this.showDamageNumber(this.player.x, this.player.y, damage, '#ffff00');
                
                // 创建闪电粒子效果
                for (let i = 0; i < 15; i++) {
                    this.particles.push({
                        x: this.player.x + (Math.random() - 0.5) * 100,
                        y: this.player.y + (Math.random() - 0.5) * 100,
                        vx: (Math.random() - 0.5) * 8,
                        vy: (Math.random() - 0.5) * 8,
                        life: 30,
                        maxLife: 30,
                        color: Math.random() > 0.5 ? '#ffff00' : '#ffffff',
                        size: Math.random() * 3 + 1,
                        type: 'lightning'
                    });
                }
                
                this.createExplosion(headSegment.x, headSegment.y, 'lightning');
            }
            
            shadowTeleport(headSegment) {
                logInfo('🌙 暗影龙瞬移攻击！');
                // 瞬移到玩家附近
                headSegment.x = this.player.x + (Math.random() - 0.5) * 200;
                headSegment.y = this.player.y + (Math.random() - 0.5) * 200;
            }
            
            updateDamageNumbers() {
                this.damageNumbers = this.damageNumbers.filter(dmg => {
                    dmg.y += dmg.vy || 0;
                    dmg.x += dmg.vx || 0;
                    dmg.life--;
                    return dmg.life > 0;
                });

                // 更新粒子系统
                this.updateParticles();

                // 更新星空闪烁效果
                this.backgroundStars.forEach(star => {
                    star.brightness += (Math.random() - 0.5) * star.twinkleSpeed;
                    star.brightness = Math.max(0.2, Math.min(1, star.brightness));
                });
            }
            
            autoShoot() {
                if (!this.stoneDragon || this.stoneDragon.segments.length === 0) return;
                
                const now = Date.now();
                if (!this.lastShot || now - this.lastShot > 200) {
                    const target = this.stoneDragon.segments[0];
                    const dx = target.x - this.player.x;
                    const dy = target.y - this.player.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance > 0) {
                        const speed = 400;
                        this.bullets.push({
                            x: this.player.x,
                            y: this.player.y,
                            vx: (dx / distance) * speed / 60,
                            vy: (dy / distance) * speed / 60,
                            damage: 10
                        });
                        this.lastShot = now;
                    }
                }
            }
            
            checkCollisions() {
                // 子弹与飞行敌人碰撞
                this.bullets.forEach((bullet, bulletIndex) => {
                    if (bullet.isEnemyBullet) return; // 敌人子弹不攻击敌人
                    
                    this.flyingEnemies.forEach((enemy, enemyIndex) => {
                        const dx = bullet.x - enemy.x;
                        const dy = bullet.y - enemy.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance < enemy.radius + bullet.radius) {
                            enemy.health -= bullet.damage;
                            this.showDamageNumber(enemy.x, enemy.y, bullet.damage, '#ffff00');
                            this.bullets.splice(bulletIndex, 1);
                            this.score += 50;
                            
                            if (enemy.health <= 0) {
                                this.flyingEnemies.splice(enemyIndex, 1);
                                this.score += 100;
                                this.createExplosion(enemy.x, enemy.y);
                            }
                        }
                    });
                });
                
                // 敌人子弹与玩家碰撞
                this.bullets.forEach((bullet, bulletIndex) => {
                    if (!bullet.isEnemyBullet) return; // 只检查敌人子弹
                    
                    const dx = bullet.x - this.player.x;
                    const dy = bullet.y - this.player.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < this.player.radius + bullet.radius) {
                        let damage = bullet.damage;
                        
                        // 护盾减伤
                        if (this.player.skills.shield.active) {
                            damage = Math.floor(damage * 0.2);
                            this.showDamageNumber(this.player.x, this.player.y, `BLOCK ${damage}`, '#4488ff');
                        } else {
                            this.showDamageNumber(this.player.x, this.player.y, damage, '#ff0000');
                        }
                        
                        this.player.health -= damage;
                        this.bullets.splice(bulletIndex, 1);
                        
                        if (this.player.health <= 0) {
                            this.gameOver = true;
                            logInfo('💀 游戏结束！');
                        }
                    }
                });
                
                // 特殊武器与石龙碰撞
                if (this.specialWeapons && this.stoneDragon) {
                    this.specialWeapons.forEach((weapon, weaponIndex) => {
                        this.stoneDragon.segments.forEach((segment, segmentIndex) => {
                            const dx = weapon.x - segment.x;
                            const dy = weapon.y - segment.y;
                            const distance = Math.sqrt(dx * dx + dy * dy);
                            
                            if (distance < 50) {
                                // 特殊武器造成大伤害
                                const armor = segment.armor || 0;
                                const actualDamage = Math.max(10, weapon.damage - armor);
                                segment.health -= actualDamage;
                                
                                this.createDamageNumber(segment.x, segment.y, actualDamage, '#ff6600');
                                this.createScreenShake(15);
                                
                                // 移除武器
                                this.specialWeapons.splice(weaponIndex, 1);
                                
                                // 如果段被摧毁
                                if (segment.health <= 0) {
                                    this.stoneDragon.segments.splice(segmentIndex, 1);
                                    this.score += segment.isHead ? 1000 : 500;
                                    
                                    // 大爆炸效果
                                    this.createExplosion(segment.x, segment.y, 2.0);
                                    
                                    // 生成强化道具
                                    if (Math.random() < 0.3) {
                                        this.treasureChests.push({
                                            x: segment.x,
                                            y: segment.y,
                                            size: 25,
                                            opened: false,
                                            sparkleTimer: 0,
                                            type: this.getRandomChestType(),
                                            glowEffect: 0
                                        });
                                    }
                                }
                            }
                        });
                    });
                }
                
                if (!this.stoneDragon) return;
                
                // 子弹与石龙碰撞
                this.bullets.forEach((bullet, bulletIndex) => {
                    this.stoneDragon.segments.forEach((segment, segmentIndex) => {
                        const dx = bullet.x - segment.x;
                        const dy = bullet.y - segment.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance < 40) {
                            // 计算实际伤害（考虑护甲）
                            const armor = segment.armor || 0;
                            const actualDamage = Math.max(1, bullet.damage - armor);
                            segment.health -= actualDamage;
                            
                            // 显示伤害数字
                            this.showDamageNumber(segment.x, segment.y, actualDamage, '#ff6666');
                            
                            this.bullets.splice(bulletIndex, 1);
                            this.score += 10;
                            
                            if (segment.health <= 0) {
                                this.stoneDragon.segments.splice(segmentIndex, 1);
                                this.score += segment.isHead ? 500 : 200; // 龙头更高分数
                                
                                // 爆炸效果
                                this.createExplosion(segment.x, segment.y);
                            }
                        }
                    });
                });
                
                // 玩家与飞行敌人碰撞
                this.flyingEnemies.forEach(enemy => {
                    const dx = this.player.x - enemy.x;
                    const dy = this.player.y - enemy.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < this.player.radius + enemy.radius) {
                        let damage = enemy.attackPower * 0.5; // 直接碰撞伤害较低
                        
                        // 护盾减伤
                        if (this.player.skills.shield.active) {
                            damage = Math.floor(damage * 0.2);
                            this.showDamageNumber(this.player.x, this.player.y, `BLOCK ${damage}`, '#4488ff');
                        } else {
                            this.showDamageNumber(this.player.x, this.player.y, damage, '#ff0000');
                        }
                        
                        this.player.health -= damage;
                        
                        // 击退效果
                        const pushX = (this.player.x - enemy.x) / distance * 30;
                        const pushY = (this.player.y - enemy.y) / distance * 30;
                        this.player.x = Math.max(this.player.radius, 
                            Math.min(this.width - this.player.radius, this.player.x + pushX));
                        this.player.y = Math.max(this.player.radius, 
                            Math.min(this.height - this.player.radius, this.player.y + pushY));
                        
                        if (this.player.health <= 0) {
                            this.gameOver = true;
                            logInfo('💀 游戏结束！');
                        }
                    }
                });

                // 玩家与石龙碰撞
                if (this.stoneDragon) {
                    this.stoneDragon.segments.forEach(segment => {
                        const dx = this.player.x - segment.x;
                        const dy = this.player.y - segment.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < this.player.radius + 30) {
                        let damage = segment.attackPower || 10;
                        
                        // 护盾减伤
                        if (this.player.skills.shield.active) {
                            damage = Math.floor(damage * 0.2); // 80%减伤
                            this.showDamageNumber(this.player.x, this.player.y, `BLOCK ${damage}`, '#4488ff');
                        } else {
                            this.showDamageNumber(this.player.x, this.player.y, damage, '#ff0000');
                        }
                        
                        this.player.health -= damage;
                        
                        // 击退效果
                        const pushX = (this.player.x - segment.x) / distance * 50;
                        const pushY = (this.player.y - segment.y) / distance * 50;
                        this.player.x = Math.max(this.player.radius, 
                            Math.min(this.width - this.player.radius, this.player.x + pushX));
                        this.player.y = Math.max(this.player.radius, 
                            Math.min(this.height - this.player.radius, this.player.y + pushY));
                        
                        if (this.player.health <= 0) {
                            this.gameOver = true;
                            logInfo('💀 游戏结束！');
                        }
                    }
                });
                
                // 危险区域伤害
                if (this.hazards) {
                    this.hazards = this.hazards.filter(hazard => {
                        hazard.duration--;
                        
                        const dx = this.player.x - hazard.x;
                        const dy = this.player.y - hazard.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance < hazard.radius) {
                            this.player.health -= hazard.damage / 60; // 持续伤害
                            this.showDamageNumber(this.player.x, this.player.y, 1, '#ff8800');
                        }
                        
                        return hazard.duration > 0;
                    });
                }
                
                // 检查石龙是否全部被消灭
                if (this.stoneDragon.segments.length === 0) {
                    this.level++;
                    this.score += 1000 * this.level; // 等级奖励
                    logInfo(`🎉 等级提升到 ${this.level}！获得 ${1000 * this.level} 分奖励！`);
                    
                    // 恢复玩家部分血量
                    this.player.health = Math.min(this.player.maxHealth, this.player.health + 50);
                    
                    this.createStoneDragon();
                }
            }
            
            showDamageNumber(x, y, damage, color) {
                this.damageNumbers.push({
                    x: x + (Math.random() - 0.5) * 40,
                    y: y - 20,
                    damage: Math.floor(damage),
                    color: color,
                    life: 60,
                    vy: -2
                });
            }
            
            generateStars() {
                const stars = [];
                for (let i = 0; i < 100; i++) {
                    stars.push({
                        x: Math.random() * this.width,
                        y: Math.random() * this.height,
                        size: Math.random() * 2 + 1,
                        brightness: Math.random() * 0.8 + 0.2,
                        twinkleSpeed: Math.random() * 0.05 + 0.01
                    });
                }
                return stars;
            }

            createParticle(x, y, type = 'explosion', options = {}) {
                switch (type) {
                    case 'explosion':
                        for (let i = 0; i < 15; i++) {
                            const angle = Math.random() * Math.PI * 2;
                            const speed = Math.random() * 5 + 2;
                            this.particles.push({
                                x: x,
                                y: y,
                                vx: Math.cos(angle) * speed,
                                vy: Math.sin(angle) * speed,
                                life: 30,
                                maxLife: 30,
                                size: Math.random() * 3 + 2,
                                color: `hsl(${Math.random() * 60 + 15}, 100%, 60%)`, // 橙红色
                                type: 'explosion'
                            });
                        }
                        break;
                    case 'trail':
                        this.particles.push({
                            x: x,
                            y: y,
                            vx: (Math.random() - 0.5) * 2,
                            vy: (Math.random() - 0.5) * 2,
                            life: 20,
                            maxLife: 20,
                            size: Math.random() * 2 + 1,
                            color: options.color || '#ffff00',
                            type: 'trail'
                        });
                        break;
                    case 'shield':
                        for (let i = 0; i < 8; i++) {
                            const angle = (Math.PI * 2 * i) / 8;
                            this.particles.push({
                                x: x + Math.cos(angle) * 30,
                                y: y + Math.sin(angle) * 30,
                                vx: Math.cos(angle) * 0.5,
                                vy: Math.sin(angle) * 0.5,
                                life: 15,
                                maxLife: 15,
                                size: 3,
                                color: '#4488ff',
                                type: 'shield'
                            });
                        }
                        break;
                }
            }

            updateParticles() {
                this.particles = this.particles.filter(particle => {
                    particle.x += particle.vx;
                    particle.y += particle.vy;
                    particle.life--;
                    
                    // 重力效果
                    if (particle.type === 'explosion') {
                        particle.vy += 0.1;
                    }
                    
                    return particle.life > 0;
                });
            }

            createExplosion(x, y) {
                // 创建爆炸粒子效果
                this.createParticle(x, y, 'explosion');
                
                // 保留原有的爆炸效果文字
                for (let i = 0; i < 5; i++) {
                    const angle = (Math.PI * 2 * i) / 5;
                    this.damageNumbers.push({
                        x: x,
                        y: y,
                        damage: '💥',
                        color: '#ffaa00',
                        life: 30,
                        vx: Math.cos(angle) * 2,
                        vy: Math.sin(angle) * 2
                    });
                }
            }
            
            render() {
                try {
                    // 清屏
                    this.ctx.fillStyle = '#0a0a0a';
                    this.ctx.fillRect(0, 0, this.width, this.height);
                    
                    // 绘制动态星空背景
                    this.backgroundStars.forEach(star => {
                        this.ctx.fillStyle = `rgba(255, 255, 255, ${star.brightness})`;
                        this.ctx.beginPath();
                        this.ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
                        this.ctx.fill();
                    });
                    
                    // 绘制玩家
                    if (this.player.skills.shield.active) {
                        // 护盾光环
                        this.ctx.strokeStyle = '#4488ff';
                        this.ctx.lineWidth = 3;
                        this.ctx.shadowColor = '#4488ff';
                        this.ctx.shadowBlur = 15;
                        this.ctx.beginPath();
                        this.ctx.arc(this.player.x, this.player.y, this.player.radius + 10, 0, Math.PI * 2);
                        this.ctx.stroke();
                        this.ctx.shadowBlur = 0;
                        
                        // 护盾粒子效果
                        if (Math.random() < 0.1) {
                            this.createParticle(this.player.x, this.player.y, 'shield');
                        }
                    }
                    
                    this.ctx.fillStyle = '#4fd1c7';
                    this.ctx.beginPath();
                    this.ctx.arc(this.player.x, this.player.y, this.player.radius, 0, Math.PI * 2);
                    this.ctx.fill();
                    
                    this.ctx.strokeStyle = '#ffffff';
                    this.ctx.lineWidth = 2;
                    this.ctx.stroke();
                    
                    // 绘制子弹
                    this.bullets.forEach(bullet => {
                        if (bullet.isPowerShot) {
                            // 强力子弹
                            this.ctx.fillStyle = '#ff4444';
                            this.ctx.shadowColor = '#ff4444';
                            this.ctx.shadowBlur = 10;
                            this.ctx.beginPath();
                            this.ctx.arc(bullet.x, bullet.y, 6, 0, Math.PI * 2);
                            this.ctx.fill();
                            this.ctx.shadowBlur = 0;
                        } else {
                            // 普通子弹
                            this.ctx.fillStyle = '#ffff00';
                            this.ctx.beginPath();
                            this.ctx.arc(bullet.x, bullet.y, 3, 0, Math.PI * 2);
                            this.ctx.fill();
                        }
                    });
                    
                    // 绘制危险区域
                    if (this.hazards) {
                        this.hazards.forEach(hazard => {
                            this.ctx.fillStyle = `rgba(255, 100, 0, ${hazard.duration / 120})`;
                            this.ctx.beginPath();
                            this.ctx.arc(hazard.x, hazard.y, hazard.radius, 0, Math.PI * 2);
                            this.ctx.fill();
                        });
                    }
                    
                    // 绘制粒子效果
                    if (this.particles) {
                        this.particles.forEach(particle => {
                            this.ctx.save();
                            this.ctx.globalAlpha = particle.alpha || 1;
                            this.ctx.fillStyle = particle.color;
                            this.ctx.beginPath();
                            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                            this.ctx.fill();
                            this.ctx.restore();
                        });
                    }
                    
                    // 绘制飞行敌人
                    if (this.flyingEnemies) {
                        this.flyingEnemies.forEach(enemy => {
                            // 敌人本体
                            this.ctx.fillStyle = enemy.color;
                            this.ctx.beginPath();
                            this.ctx.arc(enemy.x, enemy.y, enemy.size, 0, Math.PI * 2);
                            this.ctx.fill();
                            
                            // 血量条
                            const healthRatio = enemy.health / enemy.maxHealth;
                            const barWidth = enemy.size * 2;
                            const barHeight = 3;
                            const barX = enemy.x - barWidth / 2;
                            const barY = enemy.y - enemy.size - 8;
                            
                            this.ctx.fillStyle = '#333333';
                            this.ctx.fillRect(barX, barY, barWidth, barHeight);
                            
                            this.ctx.fillStyle = healthRatio > 0.5 ? '#00ff00' : '#ff0000';
                            this.ctx.fillRect(barX, barY, barWidth * healthRatio, barHeight);
                        });
                    }
                    
                    // 绘制飞行敌人
                    this.flyingEnemies.forEach(enemy => {
                        // 敌人主体
                        this.ctx.fillStyle = enemy.color;
                        this.ctx.shadowColor = enemy.color;
                        this.ctx.shadowBlur = 8;
                        this.ctx.beginPath();
                        this.ctx.arc(enemy.x, enemy.y, enemy.radius, 0, Math.PI * 2);
                        this.ctx.fill();
                        this.ctx.shadowBlur = 0;
                        
                        // 特殊效果
                        if (enemy.type === 'phoenix') {
                            // 火焰翅膀
                            this.ctx.fillStyle = '#FF6600';
                            this.ctx.beginPath();
                            this.ctx.ellipse(enemy.x - 15, enemy.y, 8, 15, 0, 0, Math.PI * 2);
                            this.ctx.ellipse(enemy.x + 15, enemy.y, 8, 15, 0, 0, Math.PI * 2);
                            this.ctx.fill();
                        } else if (enemy.type === 'storm') {
                            // 闪电效果
                            if (Math.random() < 0.3) {
                                this.ctx.strokeStyle = '#FFFF00';
                                this.ctx.lineWidth = 2;
                                this.ctx.beginPath();
                                this.ctx.moveTo(enemy.x - 10, enemy.y - 10);
                                this.ctx.lineTo(enemy.x + 10, enemy.y + 10);
                                this.ctx.moveTo(enemy.x + 10, enemy.y - 10);
                                this.ctx.lineTo(enemy.x - 10, enemy.y + 10);
                                this.ctx.stroke();
                            }
                        } else if (enemy.type === 'bat') {
                            // 翅膀扇动
                            this.ctx.fillStyle = '#654321';
                            const wingOffset = Math.sin(Date.now() * 0.02) * 5;
                            this.ctx.beginPath();
                            this.ctx.ellipse(enemy.x - 12, enemy.y + wingOffset, 6, 10, 0, 0, Math.PI * 2);
                            this.ctx.ellipse(enemy.x + 12, enemy.y - wingOffset, 6, 10, 0, 0, Math.PI * 2);
                            this.ctx.fill();
                        }
                        
                        // 血量条
                        const healthRatio = enemy.health / enemy.maxHealth;
                        const barWidth = 30;
                        const barHeight = 4;
                        const barX = enemy.x - barWidth / 2;
                        const barY = enemy.y - enemy.radius - 10;
                        
                        this.ctx.fillStyle = '#333333';
                        this.ctx.fillRect(barX, barY, barWidth, barHeight);
                        
                        this.ctx.fillStyle = healthRatio > 0.5 ? '#00ff00' : '#ff0000';
                        this.ctx.fillRect(barX, barY, barWidth * healthRatio, barHeight);
                    });

                    // 绘制强化石龙
                    if (this.stoneDragon) {
                        this.stoneDragon.segments.forEach((segment, index) => {
                            if (index === 0) {
                                // 根据龙类型改变颜色
                                let headColor = '#ff4444';
                                switch (this.stoneDragon.type) {
                                    case 'fire': headColor = '#ff4444'; break;
                                    case 'ice': headColor = '#4488ff'; break;
                                    case 'lightning': headColor = '#ffff44'; break;
                                    case 'shadow': headColor = '#444444'; break;
                                }
                                
                                // 狂暴状态发光效果
                                if (this.stoneDragon.rage) {
                                    this.ctx.shadowColor = headColor;
                                    this.ctx.shadowBlur = 20;
                                }
                                
                                // 龙头
                                this.ctx.fillStyle = headColor;
                                this.ctx.beginPath();
                                this.ctx.moveTo(segment.x, segment.y - 30);
                                this.ctx.lineTo(segment.x - 25, segment.y + 20);
                                this.ctx.lineTo(segment.x + 25, segment.y + 20);
                                this.ctx.closePath();
                                this.ctx.fill();
                                
                                // 眼睛
                                this.ctx.fillStyle = this.stoneDragon.rage ? '#ff0000' : '#ffff00';
                                this.ctx.beginPath();
                                this.ctx.arc(segment.x - 10, segment.y - 10, 5, 0, Math.PI * 2);
                                this.ctx.arc(segment.x + 10, segment.y - 10, 5, 0, Math.PI * 2);
                                this.ctx.fill();
                                
                            } else {
                                // 身体
                                this.ctx.fillStyle = '#aa4444';
                                this.ctx.beginPath();
                                this.ctx.arc(segment.x, segment.y, 25, 0, Math.PI * 2);
                                this.ctx.fill();
                            }
                            
                            // 血量条
                            const healthRatio = segment.health / segment.maxHealth;
                            const barWidth = 50;
                            const barHeight = 6;
                            const barX = segment.x - barWidth / 2;
                            const barY = segment.y - 40;
                            
                            this.ctx.fillStyle = '#333333';
                            this.ctx.fillRect(barX, barY, barWidth, barHeight);
                            
                            this.ctx.fillStyle = healthRatio > 0.5 ? '#00ff00' : '#ff0000';
                            this.ctx.fillRect(barX, barY, barWidth * healthRatio, barHeight);
                        });
                    }
                    
                    // 绘制粒子效果
                    this.particles.forEach(particle => {
                        const alpha = particle.life / particle.maxLife;
                        this.ctx.globalAlpha = alpha;
                        
                        if (particle.type === 'explosion') {
                            this.ctx.fillStyle = particle.color;
                            this.ctx.beginPath();
                            this.ctx.arc(particle.x, particle.y, particle.size * alpha, 0, Math.PI * 2);
                            this.ctx.fill();
                        } else if (particle.type === 'trail') {
                            this.ctx.fillStyle = particle.color;
                            this.ctx.beginPath();
                            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                            this.ctx.fill();
                        } else if (particle.type === 'shield') {
                            this.ctx.fillStyle = particle.color;
                            this.ctx.shadowColor = particle.color;
                            this.ctx.shadowBlur = 10;
                            this.ctx.beginPath();
                            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                            this.ctx.fill();
                            this.ctx.shadowBlur = 0;
                        }
                    });
                    this.ctx.globalAlpha = 1;
                    
                    // 绘制宝箱
                    if (this.treasureChests) {
                        this.treasureChests.forEach(chest => {
                            if (!chest.opened) {
                                // 宝箱发光效果
                                this.ctx.shadowColor = '#ffaa00';
                                this.ctx.shadowBlur = 10 + chest.glowEffect * 10;
                                
                                // 宝箱主体
                                this.ctx.fillStyle = '#8b4513';
                                this.ctx.fillRect(chest.x - chest.size/2, chest.y - chest.size/2, chest.size, chest.size);
                                
                                // 宝箱装饰
                                this.ctx.fillStyle = '#ffaa00';
                                this.ctx.fillRect(chest.x - chest.size/2 + 5, chest.y - chest.size/2 + 5, chest.size - 10, 5);
                                this.ctx.fillRect(chest.x - 3, chest.y - chest.size/2, 6, chest.size);
                                
                                // 闪烁效果
                                if (chest.sparkleTimer % 20 < 10) {
                                    this.ctx.fillStyle = '#ffffff';
                                    this.ctx.fillRect(chest.x - 2, chest.y - 2, 4, 4);
                                }
                                
                                this.ctx.shadowBlur = 0;
                            }
                        });
                    }
                    
                    // 绘制特殊武器
                    if (this.specialWeapons) {
                        this.specialWeapons.forEach(weapon => {
                            this.ctx.save();
                            
                            if (weapon.type === 'missile') {
                                // 导弹
                                this.ctx.fillStyle = '#ff6666';
                                this.ctx.shadowColor = '#ff6666';
                                this.ctx.shadowBlur = 15;
                                this.ctx.beginPath();
                                this.ctx.ellipse(weapon.x, weapon.y, 8, 3, weapon.angle || 0, 0, Math.PI * 2);
                                this.ctx.fill();
                                
                                // 导弹尾迹
                                this.ctx.strokeStyle = '#ffaa44';
                                this.ctx.lineWidth = 3;
                                this.ctx.beginPath();
                                this.ctx.moveTo(weapon.x - weapon.vx * 3, weapon.y - weapon.vy * 3);
                                this.ctx.lineTo(weapon.x, weapon.y);
                                this.ctx.stroke();
                            }
                            
                            this.ctx.restore();
                        });
                    }

                    // 绘制伤害数字
                    this.damageNumbers.forEach(dmg => {
                        this.ctx.fillStyle = dmg.color;
                        this.ctx.font = 'bold 16px Arial';
                        this.ctx.textAlign = 'center';
                        this.ctx.globalAlpha = dmg.life / 60;
                        this.ctx.fillText(dmg.damage, dmg.x, dmg.y);
                        this.ctx.globalAlpha = 1;
                    });
                    
                    // 重置阴影效果
                    this.ctx.shadowBlur = 0;
                    
                    // 游戏开始提示
                    if (!this.gameStarted) {
                        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                        this.ctx.fillRect(0, 0, this.width, this.height);
                        
                        this.ctx.fillStyle = '#ffffff';
                        this.ctx.font = 'bold 32px Arial';
                        this.ctx.textAlign = 'center';
                        this.ctx.fillText('🐉 强化石龙猎者', this.width / 2, this.height / 2 - 50);
                        
                        this.ctx.font = '18px Arial';
                        this.ctx.fillText('点击开始游戏', this.width / 2, this.height / 2);
                        this.ctx.fillText('WASD 移动 | Shift 冲刺 | Space 护盾 | Q 强击 | R 特殊武器', this.width / 2, this.height / 2 + 30);
                        this.ctx.fillText('面对更强的龙族挑战！', this.width / 2, this.height / 2 + 60);
                    }
                    
                    // 暂停菜单
                    if (this.gamePaused) {
                        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                        this.ctx.fillRect(0, 0, this.width, this.height);
                        
                        this.ctx.fillStyle = '#ffff00';
                        this.ctx.font = 'bold 32px Arial';
                        this.ctx.textAlign = 'center';
                        this.ctx.fillText('⏸️ 游戏暂停', this.width / 2, this.height / 2 - 50);
                        
                        this.ctx.fillStyle = '#ffffff';
                        this.ctx.font = '18px Arial';
                        this.ctx.fillText('按ESC继续游戏', this.width / 2, this.height / 2);
                        this.ctx.fillText('或点击屏幕继续', this.width / 2, this.height / 2 + 30);
                        
                        this.ctx.fillStyle = '#cccccc';
                        this.ctx.font = '14px Arial';
                        this.ctx.fillText('游戏操作提示:', this.width / 2, this.height / 2 + 70);
                        this.ctx.fillText('WASD - 移动 | Shift - 冲刺 | Space - 护盾 | Q - 强击 | R - 特殊武器', 
                            this.width / 2, this.height / 2 + 90);
                    }

                    // 游戏结束提示
                    if (this.gameOver) {
                        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
                        this.ctx.fillRect(0, 0, this.width, this.height);
                        
                        this.ctx.fillStyle = '#ff4444';
                        this.ctx.font = 'bold 32px Arial';
                        this.ctx.textAlign = 'center';
                        this.ctx.fillText('💀 游戏结束', this.width / 2, this.height / 2 - 50);
                        
                        this.ctx.fillStyle = '#ffffff';
                        this.ctx.font = '18px Arial';
                        this.ctx.fillText(`最终得分: ${this.score}`, this.width / 2, this.height / 2);
                        this.ctx.fillText(`达到等级: ${this.level}`, this.width / 2, this.height / 2 + 30);
                        this.ctx.fillText('刷新页面重新开始', this.width / 2, this.height / 2 + 60);
                    }
                    
                    
                } catch (error) {
                    logError('渲染失败', error);
                }
            }
            
            drawGameUI() {
                // 玩家血量条
                const hpBarWidth = 200;
                const hpBarHeight = 20;
                const hpBarX = 20;
                const hpBarY = 20;
                
                // 背景
                this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                this.ctx.fillRect(hpBarX - 5, hpBarY - 5, hpBarWidth + 10, hpBarHeight + 10);
                
                // 血量条背景
                this.ctx.fillStyle = '#333333';
                this.ctx.fillRect(hpBarX, hpBarY, hpBarWidth, hpBarHeight);
                
                // 血量条
                const healthRatio = this.player.health / this.player.maxHealth;
                const healthColor = healthRatio > 0.6 ? '#00ff00' : healthRatio > 0.3 ? '#ffff00' : '#ff0000';
                this.ctx.fillStyle = healthColor;
                this.ctx.fillRect(hpBarX, hpBarY, hpBarWidth * healthRatio, hpBarHeight);
                
                // 血量文字
                this.ctx.fillStyle = '#ffffff';
                this.ctx.font = 'bold 14px Arial';
                this.ctx.textAlign = 'center';
                this.ctx.fillText(`${Math.floor(this.player.health)}/${this.player.maxHealth}`, 
                    hpBarX + hpBarWidth / 2, hpBarY + 14);
                
                // 分数和等级
                this.ctx.textAlign = 'left';
                this.ctx.fillStyle = '#ffffff';
                this.ctx.font = 'bold 16px Arial';
                this.ctx.fillText(`分数: ${this.score}`, hpBarX, hpBarY + 35);
                this.ctx.fillText(`等级: ${this.level}`, hpBarX, hpBarY + 55);
                
                // 技能指示器
                this.drawSkillIndicators();
                
                // 龙血量条（如果存在）
                if (this.stoneDragon && this.stoneDragon.segments.length > 0) {
                    this.drawDragonHealthBar();
                }
            }
            
            drawSkillIndicators() {
                const skillY = 100;
                const skillSize = 40;
                const skillSpacing = 50;
                const startX = 20;
                
                const skills = [
                    { key: 'dash', name: '冲刺', icon: '💨', hotkey: 'Shift' },
                    { key: 'shield', name: '护盾', icon: '🛡️', hotkey: 'Space' },
                    { key: 'powerShot', name: '强击', icon: '💥', hotkey: 'Q' }
                ];
                
                skills.forEach((skill, index) => {
                    const x = startX + index * skillSpacing;
                    const skillData = this.player.skills[skill.key];
                    const isReady = skillData.cooldown <= 0;
                    const isActive = skillData.active;
                    
                    // 技能框背景
                    this.ctx.fillStyle = isActive ? 'rgba(0, 255, 0, 0.3)' : 
                                       isReady ? 'rgba(255, 255, 255, 0.2)' : 'rgba(128, 128, 128, 0.2)';
                    this.ctx.fillRect(x, skillY, skillSize, skillSize);
                    
                    // 技能框边框
                    this.ctx.strokeStyle = isActive ? '#00ff00' : isReady ? '#ffffff' : '#666666';
                    this.ctx.lineWidth = 2;
                    this.ctx.strokeRect(x, skillY, skillSize, skillSize);
                    
                    // 技能图标
                    this.ctx.font = '20px Arial';
                    this.ctx.textAlign = 'center';
                    this.ctx.fillStyle = isReady ? '#ffffff' : '#666666';
                    this.ctx.fillText(skill.icon, x + skillSize / 2, skillY + 25);
                    
                    // 冷却时间
                    if (skillData.cooldown > 0) {
                        const cooldownSec = Math.ceil(skillData.cooldown / 60);
                        this.ctx.font = 'bold 12px Arial';
                        this.ctx.fillStyle = '#ffff00';
                        this.ctx.fillText(cooldownSec.toString(), x + skillSize / 2, skillY + 35);
                    }
                    
                    // 热键提示
                    this.ctx.font = '10px Arial';
                    this.ctx.fillStyle = '#cccccc';
                    this.ctx.fillText(skill.hotkey, x + skillSize / 2, skillY + skillSize + 12);
                });
            }
            
            drawDragonHealthBar() {
                const dragonHead = this.stoneDragon.segments[0];
                if (!dragonHead) return;
                
                const barWidth = 300;
                const barHeight = 15;
                const barX = this.width - barWidth - 20;
                const barY = 20;
                
                // 计算总血量
                let totalHealth = 0;
                let maxTotalHealth = 0;
                this.stoneDragon.segments.forEach(segment => {
                    totalHealth += segment.health;
                    maxTotalHealth += segment.maxHealth;
                });
                
                const healthRatio = totalHealth / maxTotalHealth;
                
                // 背景
                this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
                this.ctx.fillRect(barX - 5, barY - 5, barWidth + 10, barHeight + 25);
                
                // 血量条背景
                this.ctx.fillStyle = '#333333';
                this.ctx.fillRect(barX, barY, barWidth, barHeight);
                
                // 血量条
                const healthColor = healthRatio > 0.6 ? '#ff4444' : healthRatio > 0.3 ? '#ff8844' : '#ff0000';
                this.ctx.fillStyle = healthColor;
                this.ctx.fillRect(barX, barY, barWidth * healthRatio, barHeight);
                
                // 龙类型和血量文字
                this.ctx.fillStyle = '#ffffff';
                this.ctx.font = 'bold 14px Arial';
                this.ctx.textAlign = 'center';
                const dragonName = this.getDragonTypeName(this.stoneDragon.type);
                this.ctx.fillText(`${dragonName} ${Math.floor(totalHealth)}/${maxTotalHealth}`, 
                    barX + barWidth / 2, barY + 28);
            }
            
            getDragonTypeName(type) {
                const names = {
                    stone: '石龙',
                    fire: '火龙',
                    ice: '冰龙',
                    lightning: '雷龙',
                    shadow: '暗影龙'
                };
                return names[type] || '神秘龙';
            }
            
            gameLoop() {
                try {
                    this.update();
                    this.render();
                    requestAnimationFrame(() => this.gameLoop());
                } catch (error) {
                    logError('游戏循环失败', error);
                }
            }
            
            spawnFlyingEnemies() {
                this.enemySpawnTimer = (this.enemySpawnTimer || 0) + 1;
                
                const spawnRate = Math.max(300 - this.level * 30, 120);
                
                if (this.enemySpawnTimer >= spawnRate) {
                    this.enemySpawnTimer = 0;
                    
                    const enemyTypes = ['bat', 'bird', 'drone'];
                    const type = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
                    
                    this.flyingEnemies.push({
                        type: type,
                        x: this.width + 50,
                        y: Math.random() * (this.height - 100) + 50,
                        health: 30 + this.level * 10,
                        maxHealth: 30 + this.level * 10,
                        speed: 1 + Math.random() * 2,
                        radius: 12 + Math.random() * 8,
                        color: ['#4a0040', '#0066cc', '#666666'][Math.floor(Math.random() * 3)],
                        attackCooldown: 0,
                        direction: Math.random() * 0.4 - 0.2
                    });
                }
            }
            
            spawnTreasureChests() {
                // 每30秒有20%概率生成宝箱
                if (this.frameCount % 1800 === 0 && Math.random() < 0.2) {
                    this.treasureChests.push({
                        x: Math.random() * (this.width - 100) + 50,
                        y: Math.random() * (this.height - 100) + 50,
                        size: 30,
                        opened: false,
                        sparkleTimer: 0,
                        type: this.getRandomChestType(),
                        glowEffect: 0
                    });
                    logInfo('✨ 神秘宝箱出现！');
                }
            }
            
            getRandomChestType() {
                const types = ['weapon', 'health', 'shield', 'speed', 'power'];
                return types[Math.floor(Math.random() * types.length)];
            }
            
            updateTreasureChests() {
                if (!this.treasureChests) this.treasureChests = [];
                
                this.treasureChests.forEach((chest, index) => {
                    chest.sparkleTimer += 1;
                    chest.glowEffect = Math.sin(chest.sparkleTimer * 0.1) * 0.5 + 0.5;
                    
                    // 检查玩家与宝箱的碰撞
                    const dx = this.player.x - chest.x;
                    const dy = this.player.y - chest.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < chest.size + this.player.size && !chest.opened) {
                        this.openTreasureChest(chest, index);
                    }
                });
                
                // 移除已打开的宝箱（延迟移除以显示效果）
                this.treasureChests = this.treasureChests.filter(chest => 
                    !chest.opened || chest.sparkleTimer < 60
                );
            }
            
            openTreasureChest(chest, index) {
                chest.opened = true;
                chest.sparkleTimer = 0;
                
                // 根据类型给予奖励
                switch (chest.type) {
                    case 'weapon':
                        this.player.weaponLevel = Math.min(5, this.player.weaponLevel + 1);
                        logInfo('🗡️ 获得武器升级！');
                        break;
                    case 'health':
                        this.player.health = Math.min(this.player.maxHealth, this.player.health + 50);
                        logInfo('❤️ 生命恢复！');
                        break;
                    case 'shield':
                        this.player.shieldEnergy = Math.min(100, this.player.shieldEnergy + 30);
                        logInfo('🛡️ 护盾充能！');
                        break;
                    case 'speed':
                        this.player.speedBoost = 300; // 5秒加速
                        logInfo('⚡ 获得加速效果！');
                        break;
                    case 'power':
                        this.player.powerBoost = 600; // 10秒威力加倍
                        logInfo('💪 攻击力增强！');
                        break;
                }
                
                // 创建特殊效果
                this.createTreasureEffect(chest.x, chest.y, chest.type);
                this.score += 500;
            }
            
            createTreasureEffect(x, y, type) {
                const colors = {
                    weapon: '#ffaa00',
                    health: '#ff4444',
                    shield: '#4444ff',
                    speed: '#44ff44',
                    power: '#ff44ff'
                };
                
                for (let i = 0; i < 20; i++) {
                    this.particles.push({
                        x: x,
                        y: y,
                        vx: (Math.random() - 0.5) * 10,
                        vy: (Math.random() - 0.5) * 10,
                        color: colors[type] || '#ffffff',
                        life: 60,
                        maxLife: 60,
                        size: 3 + Math.random() * 3
                    });
                }
            }
            
            updateSpecialWeapons() {
                if (!this.specialWeapons) this.specialWeapons = [];
                
                this.specialWeapons.forEach((weapon, index) => {
                    weapon.x += weapon.vx;
                    weapon.y += weapon.vy;
                    weapon.life--;
                    
                    // 导弹追踪逻辑
                    if (weapon.type === 'missile' && this.stoneDragon && this.stoneDragon.segments.length > 0) {
                        const target = this.stoneDragon.segments[0];
                        const dx = target.x - weapon.x;
                        const dy = target.y - weapon.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance > 0) {
                            weapon.vx += (dx / distance) * 0.3;
                            weapon.vy += (dy / distance) * 0.3;
                        }
                    }
                    
                    // 移除超时武器
                    if (weapon.life <= 0) {
                        this.specialWeapons.splice(index, 1);
                    }
                });
            }
            
            updateScreenShake() {
                if (this.screenShake > 0) {
                    this.screenShake--;
                }
            }
            
            createScreenShake(intensity) {
                this.screenShake = Math.max(this.screenShake, intensity);
            }
            
            updateFlyingEnemies() {
                if (!this.flyingEnemies) this.flyingEnemies = [];
                
                this.flyingEnemies = this.flyingEnemies.filter(enemy => {
                    // 移动
                    enemy.x -= enemy.speed;
                    enemy.y += enemy.direction;
                    
                    // 边界检测
                    if (enemy.y < 50) enemy.direction = Math.abs(enemy.direction);
                    if (enemy.y > this.height - 50) enemy.direction = -Math.abs(enemy.direction);
                    
                    // 攻击冷却
                    if (enemy.attackCooldown > 0) enemy.attackCooldown--;
                    
                    // 攻击玩家
                    if (enemy.attackCooldown <= 0 && enemy.x < this.width - 100) {
                        const dx = this.player.x - enemy.x;
                        const dy = this.player.y - enemy.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        
                        if (distance > 0 && distance < 200) {
                            this.bullets.push({
                                x: enemy.x,
                                y: enemy.y,
                                vx: (dx / distance) * 6,
                                vy: (dy / distance) * 6,
                                radius: 4,
                                damage: 10,
                                isEnemyBullet: true,
                                color: '#ff6600'
                            });
                        }
                        enemy.attackCooldown = 120;
                    }
                    
                    return enemy.x > -50 && enemy.health > 0;
                });
            }
        }
        }
    }
        // 全局游戏实例
        let game = null;
        
        // 控制函数
        function startGame() {
            if (game) {
                game.startGame();
            }
        }
        
        function pauseGame() {
            if (game) {
                game.gameStarted = !game.gameStarted;
                logInfo(game.gameStarted ? '状态: 游戏继续' : '状态: 游戏暂停');
            }
        }
        
        function resetGame() {
            const canvas = document.getElementById('gameCanvas');
            game = new DragonHunterGame(canvas);
            logInfo('状态: 游戏重置');
        }
        
        function testDragon() {
            if (game) {
                game.createStoneDragon();
                logInfo('状态: 测试石龙已生成');
            }
        }
        
        // 启动游戏
        window.addEventListener('load', () => {
            try {
                logInfo('状态: 页面加载完成');
                const canvas = document.getElementById('gameCanvas');
                
                if (!canvas) {
                    throw new Error('找不到Canvas元素');
                }
                
                game = new DragonHunterGame(canvas);
                logInfo('状态: 游戏就绪，点击开始按钮或Canvas开始游戏');
                
            } catch (error) {
                logError('游戏启动失败', error);
            }
        });
